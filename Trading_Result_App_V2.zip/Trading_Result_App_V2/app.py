import streamlit as st
import pandas as pd
import numpy as np
import yfinance as yf

st.set_page_config(page_title="Trading Result Pro V2", page_icon="📊", layout="wide")
st.title("📊 Trading Result Pro — V2")
st.caption("Quarterly Sales • EBITDA • Net Profit • EPS • P/E • Market Cap")

def qoq(curr, prev):
    if prev is None or prev == 0 or pd.isna(curr) or pd.isna(prev):
        return np.nan
    return (curr - prev) / abs(prev) * 100

@st.cache_data(ttl=1800)
def fetch(symbol):
    t = yf.Ticker(symbol + ".NS")
    info = t.info
    inc = t.quarterly_income_stmt
    if inc is None or inc.empty:
        return None, "No quarterly financial statement available"

    def find_row(names):
        for name in names:
            if name in inc.index:
                return inc.loc[name]
        return pd.Series(dtype=float)

    revenue = find_row(["Total Revenue", "Operating Revenue"])
    ebitda = find_row(["EBITDA", "Normalized EBITDA"])
    net = find_row(["Net Income", "Net Income Common Stockholders"])
    eps = find_row(["Diluted EPS", "Basic EPS"])
    dates = list(inc.columns[:4])

    def values(s):
        return [float(s.get(d, np.nan)) for d in dates]

    rv, ev, nv, ep = values(revenue), values(ebitda), values(net), values(eps)
    if len(dates) < 2:
        return None, "Insufficient quarterly data"

    return {
        "Symbol": symbol,
        "Latest Quarter": str(dates[0].date()) if hasattr(dates[0], "date") else str(dates[0]),
        "Market Cap ₹Cr": (info.get("marketCap") or np.nan) / 1e7,
        "P/E": info.get("trailingPE") or info.get("forwardPE") or np.nan,
        "Sales Latest ₹Cr": rv[0]/1e7 if pd.notna(rv[0]) else np.nan,
        "Sales Previous ₹Cr": rv[1]/1e7 if pd.notna(rv[1]) else np.nan,
        "Sales QoQ %": qoq(rv[0], rv[1]),
        "EBITDA Latest ₹Cr": ev[0]/1e7 if pd.notna(ev[0]) else np.nan,
        "EBITDA Previous ₹Cr": ev[1]/1e7 if pd.notna(ev[1]) else np.nan,
        "EBITDA QoQ %": qoq(ev[0], ev[1]),
        "Net Profit Latest ₹Cr": nv[0]/1e7 if pd.notna(nv[0]) else np.nan,
        "Net Profit Previous ₹Cr": nv[1]/1e7 if pd.notna(nv[1]) else np.nan,
        "Net Profit QoQ %": qoq(nv[0], nv[1]),
        "EPS Latest": ep[0],
        "EPS Previous": ep[1],
        "EPS QoQ %": qoq(ep[0], ep[1]),
    }, None

with st.sidebar:
    st.header("Filters")
    mincap = st.number_input("Minimum Market Cap ₹Cr", 5000, 100000, 5000, 500)
    salesmin = st.number_input("Minimum Sales QoQ %", 0.0, 100.0, 0.0, 1.0)
    ebitdamin = st.number_input("Minimum EBITDA QoQ %", 0.0, 200.0, 0.0, 1.0)
    profitmin = st.number_input("Minimum Net Profit QoQ %", 0.0, 300.0, 0.0, 1.0)
    epsmin = st.number_input("Minimum EPS QoQ %", 0.0, 300.0, 0.0, 1.0)
    maxpe = st.number_input("Maximum P/E", 1.0, 200.0, 50.0, 1.0)
    symbols = st.text_area("NSE symbols", "RELIANCE,HDFCBANK,ICICIBANK,SBIN,INFY,TCS,BHARTIARTL,LT,ITC,AXISBANK,BAJFINANCE")
    upload = st.file_uploader("Upload CSV (Symbol column)", type="csv")
    scan = st.button("🚀 RUN RESULT SCAN", type="primary", use_container_width=True)

if scan:
    if upload:
        u = pd.read_csv(upload)
        if "Symbol" not in u.columns:
            st.error("CSV must contain a Symbol column.")
            st.stop()
        syms = u["Symbol"].astype(str).str.upper().str.replace(".NS", "", regex=False).tolist()
    else:
        syms = [x.strip().upper().replace(".NS", "") for x in symbols.replace("\n", ",").split(",") if x.strip()]

    rows, errors = [], []
    bar = st.progress(0)
    for i, s in enumerate(dict.fromkeys(syms)):
        try:
            row, err = fetch(s)
            if row:
                rows.append(row)
            else:
                errors.append({"Symbol": s, "Error": err})
        except Exception as e:
            errors.append({"Symbol": s, "Error": str(e)[:120]})
        bar.progress((i + 1) / len(syms))
    bar.empty()

    df = pd.DataFrame(rows)
    if df.empty:
        st.error("No quarterly data returned.")
        st.stop()

    df["Market Cap Pass"] = df["Market Cap ₹Cr"] >= mincap
    df["Sales Pass"] = df["Sales QoQ %"] >= salesmin
    df["EBITDA Pass"] = df["EBITDA QoQ %"] >= ebitdamin
    df["Profit Pass"] = df["Net Profit QoQ %"] >= profitmin
    df["EPS Pass"] = df["EPS QoQ %"] >= epsmin
    df["PE Pass"] = df["P/E"] <= maxpe
    growth_cols = ["Sales QoQ %", "EBITDA QoQ %", "Net Profit QoQ %", "EPS QoQ %"]
    df["Result Score"] = (df[growth_cols].rank(pct=True).mean(axis=1) * 100).round(1)
    pass_cols = ["Market Cap Pass", "Sales Pass", "EBITDA Pass", "Profit Pass", "EPS Pass", "PE Pass"]
    df["All Filters Pass"] = df[pass_cols].all(axis=1)
    df = df.sort_values(["All Filters Pass", "Result Score"], ascending=[False, False])

    st.success(f"{len(df)} stocks analysed • {int(df['All Filters Pass'].sum())} passed your filters")
    a, b, c, d = st.columns(4)
    a.metric("Stocks", len(df))
    b.metric("Passing", int(df["All Filters Pass"].sum()))
    c.metric("Best Profit QoQ", f"{df['Net Profit QoQ %'].max():.1f}%")
    d.metric("Best EPS QoQ", f"{df['EPS QoQ %'].max():.1f}%")

    tabs = st.tabs(["🏆 Top Results", "📊 Full Results", "🧩 Pass/Fail", "📥 Download"])
    cols = ["Symbol", "Latest Quarter", "Market Cap ₹Cr", "Sales Latest ₹Cr", "Sales QoQ %",
            "EBITDA Latest ₹Cr", "EBITDA QoQ %", "Net Profit Latest ₹Cr", "Net Profit QoQ %",
            "EPS Latest", "EPS QoQ %", "P/E", "Result Score", "All Filters Pass"]

    with tabs[0]:
        st.dataframe(df[[c for c in cols if c in df]].head(20), use_container_width=True, hide_index=True)
    with tabs[1]:
        st.dataframe(df, use_container_width=True, hide_index=True)
    with tabs[2]:
        pc = ["Symbol"] + pass_cols + ["All Filters Pass"]
        st.dataframe(df[pc], use_container_width=True, hide_index=True)
    with tabs[3]:
        st.download_button("⬇️ Download CSV", df.to_csv(index=False).encode(), "quarterly_result_scan.csv", "text/csv")

    if errors:
        with st.expander("Data errors"):
            st.dataframe(pd.DataFrame(errors), use_container_width=True, hide_index=True)
else:
    st.info("Enter stocks or upload your CSV, then press RUN RESULT SCAN.")
    st.markdown("""
### V2 includes
- Quarterly Sales and Sales QoQ
- Quarterly EBITDA and EBITDA QoQ
- Quarterly Net Profit and Net Profit QoQ
- EPS and EPS QoQ
- Market Capitalisation
- P/E Ratio
- Result Score
- Custom filters
- Pass/Fail matrix
- CSV export
""")

# Trading Result Pro V2

Mobile-friendly quarterly-result scanner.

## Metrics
Sales QoQ, EBITDA QoQ, Net Profit QoQ, EPS QoQ, Market Cap and P/E.

## Online deployment
Upload `app.py` and `requirements.txt` to a GitHub repository and deploy the repository through Streamlit Community Cloud. The resulting `streamlit.app` URL opens in a normal mobile browser.

## Local run
pip install -r requirements.txt
streamlit run app.py

## Data note
This prototype uses Yahoo Finance quarterly statements. Field definitions and availability can vary. For production NSE/BSE result monitoring, connect a licensed fundamentals provider.

Not investment advice.
